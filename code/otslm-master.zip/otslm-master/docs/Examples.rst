
.. _examples:

########
Examples
########

The toolbox has a range of examples in the ``examples`` directory.
Additional information is provided here for some of these examples.

.. toctree::
   :maxdepth: 1

   Simple-Beams
   Advanced-Beams
   Grating-And-Lens-LiveScript
   Using-the-GPU
   Accessing-OTSLM-from-LabVIEW

