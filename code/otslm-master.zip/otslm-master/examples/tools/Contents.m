% EXAMPLES/TOOLS
%
% Examples showing how to use specific features of scripts in otslm.tools.
%
% Files
%   hologram2bsc_multibeam - Fast generation of multiple BSC beams
%
% Copyright 2019 Isaac Lenton
% This file is part of OTSLM, see LICENSE.md for information about
% using/distributing this file.
