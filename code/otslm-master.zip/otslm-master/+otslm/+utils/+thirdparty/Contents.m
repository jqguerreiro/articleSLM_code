% +THIRDPARTY
%
% This might move to a private sub-folder in future
%
% Files
%   WinOnTop - allows to trigger figure's "Always On Top" state
%
% Copyright 2019 Isaac Lenton
% This file is part of OTSLM, see LICENSE.md for information about
% using/distributing this file.
