% THIRDPARTY Licenses and information for third party components
% Additional information can be found in the documentation/comments.
%
% Files
%   bowman2017.md         - Readme file from Bowman2017 repository
%   IncePolynomials.txt   - License for IncePolynomial functions
%   WinOnTop.txt          - License for WinOnTop function
%
% Copyright 2019 Isaac Lenton
% This file is part of OTSLM, see LICENSE.md for information about
% using/distributing this file.